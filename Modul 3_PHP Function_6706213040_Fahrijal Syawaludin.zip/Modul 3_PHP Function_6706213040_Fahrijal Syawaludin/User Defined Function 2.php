<?php

	function is_prime($number)
	{
		// 1 adalah bukan bilangan prima
		if ( $number == 1 ) {
			return false;
		}
		// 2 hanya satu-satunya bilangan genap berupa bilangan prima
		if ( $number == 2 ) {
			return true;
		}
		// algoritma akar kuadrat mempercepat pengujian bilangan prima yang lebih besar
		$x = sqrt($number);
		$x = floor($x);
		
		for ( $i = 2 ; $i <= $x ; ++$i ) {
			if ( $number % $i == 0 ) {
				break;
			}
		}
		
		if( $x == $i-1 ) {
			return true;
		} else {
			return false;
		}
	}

	function cekPrima($n,$m){		
		$jumlah = 0;
		for($i = $n; $i <= $m; $i++)
		{
			
			if(is_prime($i))
			{
				echo $i.', ';
				$jumlah++;
			}
		}
		echo "<br>jumlah bilangan prima ".$jumlah."<br>";
	}
	
cekPrima(0,100);
?>