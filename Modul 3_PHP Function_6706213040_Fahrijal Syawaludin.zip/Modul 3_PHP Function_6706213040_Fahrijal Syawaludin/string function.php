<?php
$string = "D3 Rekayasa Perangkat Lunak Aplikasi";
echo "<br>".substr($string, 3);
echo "<br>".substr($string, -8);
echo "<br>".substr($string, 3,24);
?>